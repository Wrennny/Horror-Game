﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace HorrorGame.Models
{
    public partial class HorrorGameContext : DbContext
    {

        public HorrorGameContext(DbContextOptions<HorrorGameContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Audio> Audio { get; set; }
        public virtual DbSet<ButtonOptions> ButtonOptions { get; set; }
        public virtual DbSet<Buttons> Buttons { get; set; }
        public virtual DbSet<Images> Images { get; set; }
        public virtual DbSet<Scenario> Scenario { get; set; }
        public virtual DbSet<Story> Story { get; set; }

//        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//        {
//            if (!optionsBuilder.IsConfigured)
//            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
//                optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Database=HorrorGame;");
//            }
//        }

//        protected override void OnModelCreating(ModelBuilder modelBuilder)
//        {
//            modelBuilder.Entity<Audio>(entity =>
//            {
//                entity.Property(e => e.AudioId)
//                    .HasColumnName("AudioID")
//                    .ValueGeneratedNever();

//                entity.Property(e => e.AudioName).HasMaxLength(50);
//            });

//            modelBuilder.Entity<ButtonOptions>(entity =>
//            {
//                entity.HasKey(e => e.ButtonId);

//                entity.Property(e => e.ButtonId)
//                    .HasColumnName("ButtonID")
//                    .ValueGeneratedNever();
//            });

//            modelBuilder.Entity<Buttons>(entity =>
//            {
//                entity.HasKey(e => e.ButtonId);

//                entity.Property(e => e.ButtonId)
//                    .HasColumnName("ButtonID")
//                    .ValueGeneratedNever();

//                entity.HasOne(d => d.Button)
//                    .WithOne(p => p.Buttons)
//                    .HasForeignKey<Buttons>(d => d.ButtonId)
//                    .OnDelete(DeleteBehavior.ClientSetNull)
//                    .HasConstraintName("FK_Buttons_ButtonOptions");

//                entity.HasOne(d => d.ButtonNavigation)
//                    .WithOne(p => p.Buttons)
//                    .HasForeignKey<Buttons>(d => d.ButtonId)
//                    .OnDelete(DeleteBehavior.ClientSetNull)
//                    .HasConstraintName("FK_Buttons_Scenario");
//            });

//            modelBuilder.Entity<Images>(entity =>
//            {
//                entity.Property(e => e.ImagesId)
//                    .HasColumnName("ImagesID")
//                    .ValueGeneratedNever();

//                entity.Property(e => e.ImagesName)
//                    .HasMaxLength(50)
//                    .IsUnicode(false);
//            });

//            modelBuilder.Entity<Scenario>(entity =>
//            {
//                entity.Property(e => e.ScenarioId)
//                    .HasColumnName("ScenarioID")
//                    .ValueGeneratedNever();

//                entity.Property(e => e.ScenarioName).HasMaxLength(50);
//            });

//            modelBuilder.Entity<Story>(entity =>
//            {
//                entity.Property(e => e.StoryId)
//                    .HasColumnName("StoryID")
//                    .ValueGeneratedNever();

//                entity.Property(e => e.StoryChapter).HasColumnType("numeric(18, 0)");

//                entity.HasOne(d => d.StoryNavigation)
//                    .WithOne(p => p.Story)
//                    .HasForeignKey<Story>(d => d.StoryId)
//                    .OnDelete(DeleteBehavior.ClientSetNull)
//                    .HasConstraintName("FK_Story_Audio");

//                entity.HasOne(d => d.Story1)
//                    .WithOne(p => p.Story)
//                    .HasForeignKey<Story>(d => d.StoryId)
//                    .OnDelete(DeleteBehavior.ClientSetNull)
//                    .HasConstraintName("FK_Story_Images");

//                entity.HasOne(d => d.Story2)
//                    .WithOne(p => p.Story)
//                    .HasForeignKey<Story>(d => d.StoryId)
//                    .OnDelete(DeleteBehavior.ClientSetNull)
//                    .HasConstraintName("FK_Story_Scenario");
//            });

//            OnModelCreatingPartial(modelBuilder);
//        }

//        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
