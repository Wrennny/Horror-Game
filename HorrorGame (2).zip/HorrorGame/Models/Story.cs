﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HorrorGame.Models
{
    public partial class Story
    {
        [Key]
        public int StoryId { get; set; }
        public decimal? StoryChapter { get; set; }
        [Column("ScenarioId")]
        public int? ScenarioId { get; set; }
        public virtual Images Story1 { get; set; }
        [ForeignKey(nameof(ScenarioId))]
        public virtual Scenario Story2 { get; set; }
        //public virtual Audio StoryNavigation { get; set; }
    }
}
