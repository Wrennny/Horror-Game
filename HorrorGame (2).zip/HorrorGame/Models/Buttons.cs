﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HorrorGame.Models
{
    public partial class Buttons
    {
        [Key]
        public int ButtonId { get; set; }
        public string Button1 { get; set; }
        public string Button2 { get; set; }

        [Column("ScenarioId")]
        public int? ScenarioId { get; set; }

        public virtual ButtonOptions Button { get; set; }

        [ForeignKey(nameof(ScenarioId))]
        public virtual Scenario ButtonNavigation { get; set; }
    }
}
