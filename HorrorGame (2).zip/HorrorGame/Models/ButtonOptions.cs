﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HorrorGame.Models
{
    public partial class ButtonOptions
    {
        [Key]
        public int ButtonId { get; set; }
        public string Option1 { get; set; }
        public string Option2 { get; set; }
        [Column("ScenarioId")]
        public int? ScenarioId { get; set; }
        public int? Option1ScenarioId { get; set; }
        public int? Option2ScenarioId { get; set; }
        [ForeignKey(nameof(ScenarioId))]
        public virtual Scenario ButtonNavigation { get; set; }
    }
}
