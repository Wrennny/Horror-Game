﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HorrorGame.Models
{
    public partial class Images
    {
        [Key]
        public int ImagesId { get; set; }
        public byte[] ImagesType { get; set; }
        public string ImagesName { get; set; }
        [Column("ScenarioId")]
        public int? ScenarioId { get; set; }
        [ForeignKey(nameof(ScenarioId))]
        public virtual Scenario Scenario { get; set; }
        [NotMapped]
        public string ImageDataUrl { get; set; }

    }
}
