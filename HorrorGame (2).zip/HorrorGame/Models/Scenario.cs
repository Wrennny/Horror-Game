﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HorrorGame.Models
{
    public partial class Scenario
    {
        [Key]
        public int ScenarioId { get; set; }
        public string ScenarioText { get; set; }
        public string ScenarioName { get; set; }

        public virtual ButtonOptions ButtonOptions { get; set; }
        public virtual Images Images { get; set; }
        public virtual Audio Audio { get; set; }
    }
}
