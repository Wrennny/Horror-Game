﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HorrorGame.Models;

namespace HorrorGame.Repositories
{
    public class HorrorRepository: IHorrorRepository
    {
        private HorrorGameContext Db;
        public HorrorRepository(HorrorGameContext _Db)
        {
            Db = _Db;
        }
        public Scenario GetScenario(int? id=1)
        {
            if (Db != null)
            {
                var list = GetScenarios();
                return list.FirstOrDefault(x => x.ScenarioId == id);
            }
            return null;
        }
        public Images GetImages(int scenarioid)
        {
            if (Db != null)
            {
                
                    Images img = new Images();
                    img = Db.Images.FirstOrDefault(x => x.ScenarioId == scenarioid);
                if (img == null) return img;
                    string imageBase64Data = Convert.ToBase64String(img.ImagesType);
                    img.ImageDataUrl = string.Format("data:image/jpg;base64,{0}", imageBase64Data);
                    return img;
            }
            return null;
        }
        public Audio GetAudio(int scenarioid)
        {
            if (Db != null)
            {
                return Db.Audio.FirstOrDefault(x => x.ScenarioId == scenarioid);
            }
            return null;
        }
        public ButtonOptions GetButtonOptions(int scenarioid)
        {
            if (Db != null)
            {
                return Db.ButtonOptions.FirstOrDefault(x => x.ScenarioId == scenarioid);
            }
            return null;
        }
        private List<Scenario> GetScenarios()
        {
            try
            {
                return Db.Scenario.ToList();
            }
            catch(Exception ex)
            {
                throw ex;
            } 
        }
    }
}
