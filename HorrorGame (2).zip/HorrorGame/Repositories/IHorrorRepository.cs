﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HorrorGame.Models;

namespace HorrorGame.Repositories
{
    public interface IHorrorRepository
    {
        Scenario GetScenario(int? id);
        Images GetImages(int Imagesid);
        Audio GetAudio(int Audioid);
        ButtonOptions GetButtonOptions(int Buttonid);
    }
}
