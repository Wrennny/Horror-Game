﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using HorrorGame.Models;
using HorrorGame.Repositories;

namespace HorrorGame.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IHorrorRepository repository;

        public HomeController(ILogger<HomeController> logger, IHorrorRepository repository)
        {
            _logger = logger;
            this.repository = repository;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Game(int? id=1)
        {
            var scenario = repository.GetScenario(id??1);

            scenario.ButtonOptions = repository.GetButtonOptions(scenario.ScenarioId);
            scenario.Images = repository.GetImages(scenario.ScenarioId);
            scenario.Audio = repository.GetAudio(scenario.ScenarioId);
            return View(scenario);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
